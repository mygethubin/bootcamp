# print("I am a student")
 
# print('I am an Innovator')
# print('I am an "innovator" ' )
# print("I am an 'innovator'")
 
# roll_number = 34
# student_name = "Jitender Chauhan"
# print(roll_number)
# print(student_name)
 
# user_name = "Jitender"
# password = "1234hjjkj"
 
# print(user_name)
# print(password)
 
user_name =input("What is your UserName?\n")
password = input("What is your password?\n")
 
print(user_name)
print(password)
 
weight = float(input("What is your weight " + user_name+ "?\n"))
height = float(input("What is your height in meter " + user_name+"?\n"))
 
BMI = weight/(height*height)
 
print(f"Dear {user_name} your BMI is {BMI}")
